
"use client";

import {
  useEffect,
  useState,
} from "react";

import {
  useAccount,
} from "wagmi";


import {
  approveAsset,
  borrowAsset,
  repayAsset,
  withdrawAsset,
  getAssetAllowance,
  getUserAccountData,
  supplyAsset,
} from "~~/services/aave/pool";

import {
  getAllReserveData,
} from "~~/services/aave/reserve";

import type {
  ReserveData,
  UserAccountData,
} from "~~/types/aave";


import {
  getWalletBalances,
} from "~~/services/aave/token";

import type {
  WalletBalance,
} from "~~/types/aave";


import {
  formatAPY,
  formatHealthFactor,
  formatLTV,
  formatTokenAmount,
  formatUSD,
} from "~~/utils/aaveFormat";


import {
  getUserPositions,
} from "~~/services/aave/reserve";

import type {
  UserReserveData,
} from "~~/types/aave";


import {
  DashboardHeader,
} from "~~/components/aave/DashboardHeader";


import {
  AccountOverview,
} from "~~/components/aave/AccountOverview";


import {
  ActionPanel,
} from "~~/components/aave/ActionPanel";


import {
  SupplyCard,
} from "~~/components/aave/SupplyCard";

import {
  BorrowCard,
} from "~~/components/aave/BorrowCard";


import {
  WithdrawCard,
} from "~~/components/aave/WithdrawCard";


import {
  RepayCard,
} from "~~/components/aave/RepayCard";

import {
  MarketsTable,
} from "~~/components/aave/MarketsTable";

import {
  PositionsTable,
} from "~~/components/aave/PositionsTable";

import {
  WalletBalancesTable,
} from "~~/components/aave/WalletBalancesTable";





export default function TestPage() {
  const {
    address,
  } = useAccount();

  const [loading, setLoading] =
    useState(false);

  const [
    accountData,
    setAccountData,
  ] =
    useState<UserAccountData | null>(
      null,
    );

  const [
    reserves,
    setReserves,
  ] = useState<
    ReserveData[]
  >([]);

 
  const [
    userPositions,

    setUserPositions,
  ] = useState<
    UserReserveData[]
  >([]);


const [
  walletBalances,

  setWalletBalances,
] = useState<
  WalletBalance[]
>([]);


const [
  selectedAsset,

  setSelectedAsset,
] = useState<
  `0x${string}` |
  ""
>("");

const [
  supplyAmount,

  setSupplyAmount,
] = useState("");


const [
  borrowAmount,

  setBorrowAmount,
] = useState("");

const [
  borrowAssetAddress,

  setBorrowAssetAddress,
] = useState<
  `0x${string}` |
  ""
>("");


const [
  withdrawAmount,

  setWithdrawAmount,
] = useState("");

const [
  withdrawAssetAddress,

  setWithdrawAssetAddress,
] = useState<
  `0x${string}` |
  ""
>("");

const [
  repayAmount,

  setRepayAmount,
] = useState("");

const [
  repayAssetAddress,

  setRepayAssetAddress,
] = useState<
  `0x${string}` |
  ""
>("");



  useEffect(() => {
    if (address) {
      loadReserves();
      loadAccountData();
    }
  }, [address]);

  async function loadReserves() {
    try {
      const data =
        await getAllReserveData();

      setReserves(data);

      if (address) {
        const positions =
          await getUserPositions(
            address as `0x${string}`,
          );
        setUserPositions(
          positions,
        );
      
        const balances =
          await getWalletBalances(
            address as `0x${string}`,
          );

        setWalletBalances(
          balances,
        );
      }

    } catch (err) {
      console.error(err);
    }
  }

  async function loadAccountData() {
    if (!address) {
      return;
    }

    try {
      const data =
        await getUserAccountData(
          address as `0x${string}`,
        );
     
      const formattedData: UserAccountData =
        {
          totalCollateral:
            formatUSD(
              data[0],
            ),

          totalDebt:
            formatUSD(
              data[1],
            ),

          availableBorrows:
            formatUSD(
              data[2],
            ),

          ltv:
            formatLTV(
              data[4],
            ),

          healthFactor:
            formatHealthFactor(
              data[5],
            ),
        };

      setAccountData(
        formattedData,
      );
    } catch (err) {
      console.error(err);
    }
  }

  async function handleSupply() {
    if (!address) {
      return;
    }

    const userAddress =
      address as `0x${string}`;

    try {
      setLoading(true);

      /**
       * 100 USDC
       */
      
      if (
        !selectedAsset ||
        !supplyAmount
      ) {
        return;
      }

      const selectedBalance =
        walletBalances.find(
          balance =>
            balance.asset ===
            selectedAsset,
        );

      if (
        !selectedBalance
      ) {
        return;
      }

      const parsedAmount =
        Number(
          supplyAmount,
        );
      if ( Number.isNaN( parsedAmount, ) || parsedAmount <= 0 ) { alert( "Invalid amount", ); return; }
      
      
      const amount =
        BigInt(
          Math.floor(
            parsedAmount *
            10 **
              selectedBalance.decimals,
          ),
        );
      if ( amount > selectedBalance.balance ) { alert( "Insufficient balance", ); return; }
      
      const allowance = 
        await getAssetAllowance( 
          selectedAsset, 
          userAddress, 
        ); 
      if ( allowance < amount 
      ) {

      /**
       * Approve
       */
      await approveAsset(
        selectedAsset
,
        amount,
      );

      console.log(
        "Approve success",
      );}

      /**
       * Supply
       */
      await supplyAsset(
        selectedAsset,
        amount,
        userAddress,
      );

      console.log(
        "Supply success",
      );

      /**
       * Reload account data
       */
      await loadAccountData();

      await loadReserves();

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }
  const handleBorrow =
    async () => {

    if (
      !borrowAssetAddress ||
      !borrowAmount ||
      !address
    ) {
      return;
    }

    const selectedReserve =
      reserves.find(
        reserve =>
          reserve.asset ===
          borrowAssetAddress,
      );

    if (
      !selectedReserve
    ) {
      return;
    }

    const parsedAmount =
      Number(
        borrowAmount,
      );

    if (
      Number.isNaN(
        parsedAmount,
      ) ||
      parsedAmount <= 0
    ) {
      alert(
        "Invalid borrow amount",
      );

      return;
    }

    const amount =
      BigInt(
        Math.floor(
          parsedAmount *
          10 **
            selectedReserve.decimals,
        ),
      );
    
    if (
      !accountData
    ) {
      return;
    }

    const availableBorrows =
      Number(
        accountData
          .availableBorrows,
      );

    if (
      parsedAmount >
      availableBorrows
    ) {
      alert(
        "Borrow amount exceeds limit",
      );

      return;
    }
   

    try {
      await borrowAsset(
        borrowAssetAddress,

        amount,

        address as `0x${string}`,
      );

      alert(
        "Borrow success",
      );

      await loadAccountData();

      await loadReserves();

    } catch (
      error
    ) {
      console.error(
        error,
      );

      alert(
        "Borrow failed",
      );
    }
  };


  const handleWithdraw =
    async () => {

    if (
      !withdrawAssetAddress ||
      !withdrawAmount ||
      !address
    ) {
      return;
    }

    const position =
      userPositions.find(
        position =>
          position.asset ===
          withdrawAssetAddress,
      );

    if (
      !position
    ) {
      return;
    }

    const parsedAmount =
      Number(
        withdrawAmount,
      );

    if (
      Number.isNaN(
        parsedAmount,
      ) ||
      parsedAmount <= 0
    ) {
      alert(
        "Invalid withdraw amount",
      );

      return;
    }

    const amount =
      BigInt(
        Math.floor(
          parsedAmount *
          10 **
            position.decimals,
        ),
      );

    if (
      amount >
      position.supplied
    ) {
      alert(
        "Withdraw amount exceeds supplied balance",
      );

      return;
    }

    try {
      await withdrawAsset(
        withdrawAssetAddress,

        amount,

        address as `0x${string}`,
      );

      alert(
        "Withdraw success",
      );

      await loadAccountData();

      await loadReserves();

    } catch (
      error
    ) {
      console.error(
        error,
      );

      alert(
        "Withdraw failed",
      );
    }
  };
  const handleWithdrawMax = async () => {
    if (!withdrawAssetAddress || !address) {
      return;
    }

    const position = userPositions.find(
      p => p.asset === withdrawAssetAddress,
    );

    if (!position) {
      return;
    }

    const supplied =
      position.supplied;

    if (supplied === 0n) {
      alert("No supplied balance");
      return;
    }

    try {
      await withdrawAsset(
        withdrawAssetAddress,
        supplied,
        address as `0x${string}`,
      );
    } catch (err: any) {
      if (
        err?.message?.includes("User denied") ||
        err?.message?.includes("rejected")
      ) {
        console.log("User cancelled withdraw");
        return;
      }

      console.error(err);
    }

    alert("Withdraw Max success");

    await loadAccountData();
    await loadReserves();
  };

  
  const handleRepay =
    async () => {

    if (
      !repayAssetAddress ||
      !repayAmount ||
      !address
    ) {
      return;
    }

    const position =
      userPositions.find(
        position =>
          position.asset ===
          repayAssetAddress,
      );

    if (
      !position
    ) {
      return;
    }

    const walletBalance =
      walletBalances.find(
        balance =>
          balance.asset ===
          repayAssetAddress,
      );

    if (
      !walletBalance
    ) {
      return;
    }

    const parsedAmount =
      Number(
        repayAmount,
      );

    if (
      Number.isNaN(
        parsedAmount,
      ) ||
      parsedAmount <= 0
    ) {
      alert(
        "Invalid repay amount",
      );

      return;
    }

    const amount =
      BigInt(
        Math.floor(
          parsedAmount *
          10 **
            position.decimals,
        ),
      );

    if (
      amount >
      position.variableDebt
    ) {
      alert(
        "Repay amount exceeds debt",
      );

      return;
    }

    if (
      amount >
      walletBalance.balance
    ) {
      alert(
        "Insufficient wallet balance",
      );

      return;
    }

    try {

      const allowance =
        await getAssetAllowance(
          repayAssetAddress,

          address as `0x${string}`,
        );

      if (
        allowance < amount
      ) {

        await approveAsset(
          repayAssetAddress,

          amount,
        );
      }

      await repayAsset(
        repayAssetAddress,

        amount,

        address as `0x${string}`,
      );

      alert(
        "Repay success",
      );

      await loadAccountData();

      await loadReserves();

    } catch (
      error
    ) {
      console.error(
        error,
      );

      alert(
        "Repay failed",
      );
    }
  };

  const handleRepayMax = async () => {
    if (!repayAssetAddress || !address) {
      return;
    }

    const position = userPositions.find(
      p => p.asset === repayAssetAddress,
    );

    if (!position) {
      return;
    }

    const debt =
      position.variableDebt +
      position.stableDebt;

    if (debt === 0n) {
      alert("No debt");
      return;
    }

    const allowance =
      await getAssetAllowance(
        repayAssetAddress,
        address as `0x${string}`,
      );

    if (allowance < debt) {
      await approveAsset(
        repayAssetAddress,
        debt,
      );
    }

    try {
      await repayAsset(
        repayAssetAddress,
        debt,
        address as `0x${string}`,
      );
    } catch (err: any) {
      if (
        err?.message?.includes("User denied") ||
        err?.message?.includes("rejected")
      ) {
        console.log("User cancelled repay");
        return;
      }

      console.error(err);
    }

    alert("Repay Max success");

    await loadAccountData();
    await loadReserves();
  };




  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">

      <div className="max-w-7xl mx-auto p-8 space-y-8 relative z-10 space-y-8">

        <DashboardHeader />
    
        <AccountOverview
          accountData={
            accountData
          }
        />
      <ActionPanel>
      <SupplyCard
        selectedAsset={
          selectedAsset
        }

        setSelectedAsset={
          setSelectedAsset
        }

        supplyAmount={
          supplyAmount
        }

        setSupplyAmount={
          setSupplyAmount
        }

        walletBalances={
          walletBalances
        }

        handleSupply={
          handleSupply
        }

        loading={
          loading
        }

     
        address={
          address as
            `0x${string}` |
            undefined
        }

      />
      
      <BorrowCard
        borrowAssetAddress={
          borrowAssetAddress
        }

        setBorrowAssetAddress={
          setBorrowAssetAddress
        }

        borrowAmount={
          borrowAmount
        }

        setBorrowAmount={
          setBorrowAmount
        }

        reserves={
          reserves
        }

        handleBorrow={
          handleBorrow
        }

        address={
          address as
            `0x${string}` |
            undefined
        }
      />
    
      <WithdrawCard
        withdrawAssetAddress={
          withdrawAssetAddress
        }

        setWithdrawAssetAddress={
          setWithdrawAssetAddress
        }

        withdrawAmount={
          withdrawAmount
        }

        setWithdrawAmount={
          setWithdrawAmount
        }

        userPositions={
          userPositions
        }

        handleWithdraw={
          handleWithdraw
        }
        
        handleWithdrawMax={
          handleWithdrawMax
        }

        address={
          address as
            `0x${string}` |
            undefined
        }
      />
     
      <RepayCard
        repayAssetAddress={
          repayAssetAddress
        }

        setRepayAssetAddress={
          setRepayAssetAddress
        }

        repayAmount={
          repayAmount
        }

        setRepayAmount={
          setRepayAmount
        }

        userPositions={
          userPositions
        }

        handleRepay={
          handleRepay
        }
        handleRepayMax={
          handleRepayMax
        }

        address={
          address as
            `0x${string}` |
            undefined
        }
      />

      
      </ActionPanel>
      
      <WalletBalancesTable
        walletBalances={
          walletBalances
        }
      />

      <MarketsTable
        reserves={
          reserves
        }
      />

      <PositionsTable
        userPositions={
          userPositions
        }
      />
    </div>
  </div>
);
}


